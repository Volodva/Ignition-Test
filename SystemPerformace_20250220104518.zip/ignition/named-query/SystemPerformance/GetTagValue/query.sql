SELECT 
	* 
FROM 
	dbo.SystemPerformance 
WHERE
	tagpath like :tagpath
	AND timestamp BETWEEN :startDate AND :endDate