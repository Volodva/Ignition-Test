INSERT INTO
	[dbo].[SystemPerformance]
	([tagpath], [tagvalue], [tagdatatype], [timestamp])
VALUES
	(:tagpath, :tagvalue, :tagDataType, :timestamp)