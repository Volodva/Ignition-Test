SELECT
	 VeteranStatus, count(VeteranStatus)
FROM
	cmClient 
GROUP BY VeteranStatus
order by count(VeteranStatus) DESC