SELECT
	 Ethnicity, count(Ethnicity)
FROM
	cmClient 
GROUP BY Ethnicity
order by count(Ethnicity) DESC