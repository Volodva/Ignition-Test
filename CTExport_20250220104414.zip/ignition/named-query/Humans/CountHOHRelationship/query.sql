SELECT
	 RelationToFamilyHead, count(RelationToFamilyHead)
FROM
	cmClient 
GROUP BY RelationToFamilyHead
order by count(RelationToFamilyHead) DESC