SELECT
	 Gender, count(Gender)
FROM
	cmClient 
GROUP BY Gender
order by gender