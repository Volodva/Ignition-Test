SELECT
	 ActiveStatus, count(ActiveStatus)
FROM
	cmClient 
GROUP BY ActiveStatus