SELECT
	 SSNQuality, count(SSNQuality)
FROM
	cmClient 
GROUP BY SSNQuality