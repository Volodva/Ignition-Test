SELECT
	 HUDRace, count(HUDRace)
FROM
	cmClient 
GROUP BY HUDRace
order by HUDRace