SELECT
	 BirthDateQuality, count(BirthDateQuality)
FROM
	cmClient 
GROUP BY BirthDateQuality
order by count(BirthDateQuality) DESC