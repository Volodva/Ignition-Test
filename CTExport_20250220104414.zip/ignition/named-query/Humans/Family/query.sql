SELECT
	 FamilyAcctID as 'id',
	 FamilyName as 'surname',
	 CreatedDate as 'timeCreated'
FROM  cmFamilyAccFile 