SELECT 
 	c.ClientID as 'id'
 	,c.FirstName  as 'firstName'
 	,c.MiddleInitial  as 'middlename'
 	,c.LastName  as 'lastname'
 	,NULL as 'nickname'
 	,c.Suffix as 'suffix'
 	,c.Birthdate  as 'dob'
 	,c.FamilyAcct as 'familyid'
 	,c.HomePhone  as 'phone'
 	,c.Email  as 'email'
 	,e.Name as 'emergencyContactName'
 	,e.HomePhone  as 'emergencyContactPhone'
 	,e.emailAddress as 'emergencyContactEmail'
 	,c.CreatedDate  as 'timeCreated'
 	,c.DeceaseDate  as 'timeDeceased'
 	,CASE
 		WHEN c.ActiveStatus = 'D' THEN GetDate()
 		ELSE Null
 	 END as 'timeRetired'
 	,CONCAT_WS(' ',c.Address, c.Address2) as 'street'
 	,c.City as 'city'
 	,c.State  as 'state'
 	,CAST(ZipCode as INT) as 'zipCode'---convert to INT!!
 	,c.MsgPhone  as 'altPhone'
 	,Null as 'preferredCommunication'
 	,Null as 'pictureId'
	,c.ClientID as 'CTID'
	,c.SocSecNo  as 'SSN'
	,NULL as 'dobQuality'--Not used in DISCOVERY
	,NULL as 'employer'
	,NULL as 'school'
	,NULL as 'congregationId'
	,CASE
		WHEN c.SSNQuality  = 1 THEN 2
		WHEN c.SSNQuality = 2 THEN 3
		WHEN c.SSNQuality = 8 THEN 4
		WHEN c.SSNQuality = 9 THEN 5
		ELSE 6
	END as 'ssnQualityId'
	,CASE
		WHEN c.Gender = 1 THEN 1
		WHEN c.Gender = 2 THEN 0
		WHEN c.Gender = 3 THEN 2
		WHEN c.Gender = 4 THEN 7
		WHEN c.Gender = 5 THEN 3
		WHEN c.Gender = 6 THEN 9
		WHEN c.Gender = 7 THEN 4
		WHEN c.Gender = 9 THEN 5
		ELSE 5
	END as 'genderId'
	----RaceId needs to be corrected----
	,CASE
		WHEN r.Race = 1 THEN 8
		ELSE 8
	END as 'raceId'
	,CASE
	 	WHEN RelationToFamilyHead = 'SL' THEN 0
	 	WHEN RelationToFamilyHead = 'S' THEN 2
	 	WHEN RelationToFamilyHead = 'D' THEN 3
	 	WHEN RelationToFamilyHead = 'SP' THEN 7
	 	WHEN RelationToFamilyHead = 'P' THEN 1
	 	WHEN RelationToFamilyHead = 'DC' THEN 4
	 	WHEN RelationToFamilyHead = 'F' THEN 9
	 	WHEN RelationToFamilyHead = 'O' THEN 10
	 	WHEN RelationToFamilyHead = 'GP' THEN 5
	 	WHEN RelationToFamilyHead = 'SB' THEN 11
	 	WHEN RelationToFamilyHead = 'OC' THEN 6
	 	ELSE 8	 	
	 END as 'hohRelationshipId'
	,3 as 'communicationTypeId' --Data not collected
	,CASE
		WHEN BirthDateQuality = 1 THEN 2
		WHEN BirthDateQuality = 8 THEN 4
		WHEN BirthDateQuality = 99 THEN 6
		WHEN BirthDateQuality = 9 THEN 5
		WHEN BirthDateQuality = 2 THEN 3
		ELSE 6
	 END as 'dobQualityId'
	,CASE
		WHEN HUDEthnicity = 'O' THEN 1
		WHEN HUDEthnicity = 'H' THEN 0
		WHEN HUDEthnicity = '8' THEN 2
		WHEN HUDEthnicity = '9' THEN 3
		WHEN HUDEthnicity = '99' THEN 4
		ELSE 4
	 END as 'ethnicityId'
	,CASE 
		WHEN DisablingCondition = 0 THEN 1
		WHEN DisablingCondition = 1 THEN 0
		WHEN DisablingCondition = 8 THEN 2
		WHEN DisablingCondition = 9 THEN 3
		WHEN DisablingCondition = 99 THEN 4
		ELSE 4  
	 END as 'disabilityTypeId'
	,CASE
		WHEN VeteranStatus = 0 THEN 1
		WHEN VeteranStatus = 1 THEN 0
		WHEN VeteranStatus = 8 THEN 2
		WHEN VeteranStatus = 9 THEN 3
		WHEN VeteranStatus = 99 THEN 4
	 END as 'veteranStatusId'
	,6 as 'emergencyContactTypeId'
	,Null as 'InsuranceTypeID'
	,Null as 'trimorbid'
	,Null as 'chronicHomeless'
	,Null as 'sexOffendRegistry'
	,Null as 'mailService'
	-- Full registration needs to look at First, Last, Gender, SSN Quality, DOB, DOB Quality, Race, Ethnicity, Veteran
	,0 as 'fullRegistration'
	


FROM cmClient c
LEFT JOIN  ClientRace r on c.ClientID = r.ClientID
LEFT JOIN  cmInterOther e on c.ClientID = e.ClientID
