SELECT
	 DisablingCondition, count(DisablingCondition)
FROM
	cmClient 
GROUP BY DisablingCondition
order by count(DisablingCondition) DESC