SELECT DISTINCT 
	b.ClientID
	,b.BeginDate 
	,b.EndDate
	,b.Restriction 
	,c.FirstName
	,c.LastName
	,c.Birthdate 
FROM BarList b
INNER JOIN cmClient c on b.ClientID = c.ClientID
WHERE EndDate is null or EndDate > GetDate()
order by b.BeginDate DESC