SELECT 
	e.EnrollID as 'id'
	,e.ClientID  as 'participantId'
	--,cmc.FirstName
	--,cmc.LastName
	,ip.id as 'programId'
	--,c.ProgramID  as 'CTprogramId'
	--,p.ProgramName as 'CTProgramName'
	--,ip.ProgramName as 'programName'

FROM Enrollment  e
Left JOIN  EnrollmentCase c on e.CaseID = c.CaseID
left join  Programs p on c.ProgramID = p.ProgramID
left join RITIOps.interaction.program ip on c.ProgramID = ip.ctid
left join  cmClient cmc on e.ClientID = cmc.ClientID

--WHERE ip.id is Not Null