SELECT 
 	c.ClientID as 'id'
	,c.ClientID as 'humanId'
	,0 as 'caseManagerId'
	,c.ClientID as 'trackId'
	,c.CreatedDate as 'timeCreated'
	,CASE
		WHEN c.ActiveStatus = 'D' THEN GetDate()
		ELSE NULL
	END	as timeRetired
	,0 as 'suspensionActive'
	,c.CreatedDate as 'timeRegistered'
	,c.UpdatedDate as 'timeUpdated'

FROM cmClient c