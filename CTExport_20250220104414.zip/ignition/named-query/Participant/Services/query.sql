SELECT 
	s.ServiceID as 'id'
	,s.ClientID  as 'participantId'
	--,cmc.FirstName
	--,cmc.LastName
	--,s.EnrollID as 'CT Enroll ID' 
	, 0 as 'employeeId'
	--,c.ProgramID  as 'CTprogramId'
	,ISNULL(ip.id,47) as 'programId'
	--,p.ProgramName as 'CTProgramName'
	--,sc.ServiceCodeID as 'CTServiceID'
	,iser.id as Serviceid
	--,iser.serviceName as 'ServiceName'
	--,sc.Service as 'CTService Name'
	,s.CreatedDate as 'timeCreated'
	,'ClientTrackImport' as 'userName'
	,0 as 'HMIS'
	,s.Units as 'quantity'
	,'Imported from Client Track' as 'comment' 

FROM Service s
LEFT JOIN ServiceCode sc on s.ServiceCodeID = sc.ServiceCodeID
LEFT JOIN RITIOps.interaction.Service iser on sc.ServiceCodeID = iser.ctid
LEFT JOIN enrollment e on s.enrollID = e.EnrollID
Left JOIN  EnrollmentCase c on e.CaseID = c.CaseID
left join  Programs p on c.ProgramID = p.ProgramID
left join RITIOps.interaction.program ip on c.ProgramID = ip.ctid
left join  cmClient cmc on e.ClientID = cmc.ClientID
