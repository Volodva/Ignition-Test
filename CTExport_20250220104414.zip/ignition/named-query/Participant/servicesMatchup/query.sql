SELECT 
	count(s.ServiceID) as 'Occurance Count'
	--,s.ClientID  as 'participantId'
	--,cmc.LastName as 'participant count'
	--,s.EnrollID as 'CT Enroll ID' 
	--, 0 as 'employeeId'
	--,c.ProgramID  as 'CTprogramId'
	--,ip.id as 'programId'
	--,p.ProgramName as 'CTProgramName'
	,sc.ServiceCodeID as 'CTServiceID'
	--,count(iser.id) as Serviceid
	,iser.serviceName as 'ServiceName'
	,sc.Service as 'CTService Name'
	--,s.CreatedDate as 'timeCreated'
	--,'ClientTrackImport' as 'userName'
	--,0 as 'HMIS'
	--,s.Units as 'quantity'
	--,'Imported from Client Track' as 'comment' 

FROM Service s
LEFT JOIN ServiceCode sc on s.ServiceCodeID = sc.ServiceCodeID
LEFT JOIN RITIOps.interaction.Service iser on sc.ServiceCodeID = iser.ctid
left join  cmClient cmc on s.ClientID = cmc.ClientID



group by sc.ServiceCodeID,sc.Service,iser.serviceName

ORDER BY count(s.ServiceID) DESC