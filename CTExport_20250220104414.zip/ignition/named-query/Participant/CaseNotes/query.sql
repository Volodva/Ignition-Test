SELECT top 10
	 d.DocumentID as 'id'
	--,l.linkID as 'participantId'
	--,c.FirstName
	--,c.LastName 
	--,0 as 'employeeId'
	--,0 as 'HMIS'
	,left(d.HTMLText,199) as 'Note'
	--,d.CreatedDate as 'timeCreated'
	--,'ClientTrackImport' as 'userName'
	--,d.UpdatedDate as 'noteDate'
	--,10 as 'CaseNoteTypeID'


FROM DocumentCatalog d
Left JOIN  DocumentLink l on d.DocumentID = l.DocumentID 
--Left JOIN cmClient c on l.linkID = c.ClientID

WHERE d.HTMLText is Not Null